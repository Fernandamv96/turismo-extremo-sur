# SPEC.md — Turismo Extremo Sur

## 1. Concept & Vision

Sitio web informativo y de contacto para **Turismo Extremo Sur**, empresa de viajes a caballo y caminatas en Punta Arenas, Chile. El diseño evoca la naturaleza austral chilena: tonos verdes y azules del sur de Chile, tipografía robusta que transmite aventura, y una estética minimalista pero cálida. El objetivo es informar, generar confianza y captar consultas de clientes potenciales.

---

## 2. Design Language

### Aesthetic Direction
Inspirado en la naturaleza magallánica: verde tundra, azul patagónico, piedra y niebla. Diseño limpio con acentos naturales.

### Color Palette
| Rol        | Color     | Hex       |
|------------|-----------|-----------|
| Primary    | Verde Tundra | `#2E7D32` |
| Secondary  | Azul Patagónico | `#1565C0` |
| Accent     | Naranja Fogata | `#E65100` |
| Background | Blanco Niebla | `#FAFAFA` |
| Text       | Gris Piedra | `#37474F` |
| Light      | Gris Claro | `#ECEFF1` |

### Typography
- **Títulos**: `Montserrat` (700, 600) — Sans-serif robusta
- **Cuerpo**: `Open Sans` (400, 500) — Legible y moderna
- **Fallback**: `system-ui, sans-serif`

### Spatial System
- Contenedor máximo: 1200px centrado
- Padding secciones: 80px vertical
- Espaciado entre elementos: 24px base
- Border-radius: 8px tarjetas, 4px inputs

### Motion Philosophy
- Transiciones suaves de 0.3s ease para hover
- Fade-in de servicios al cargar página (opacity 0→1, 400ms)
- Feedback visual en validaciones (borde rojo/verde)

---

## 3. Layout & Structure

### Arquitectura de Página (Single Page)
```
[Navbar fijo] — Navegación horizontal con logo y 3 enlaces
  ↓
[Hero] — Imagen de fondo con título y slogan
  ↓
[¿Quiénes Somos?] — Cards de integrantes del equipo
  ↓
[Nuestros Servicios] — Grid de servicios dinámicos (DOM)
  ↓
[Ubicación] — Mapa de Google Maps de Punta Arenas
  ↓
[Contáctanos] — Formulario con validaciones JS
  ↓
[Footer] — Datos de contacto y copyright
```

### Responsive Strategy
- Desktop (>1024px): 3 cards en fila para servicios
- Tablet (768-1024px): 2 cards por fila
- Mobile (<768px): 1 card por fila, menú hamburguesa

---

## 4. Features & Interactions

### Barra de Navegación
- Links: ¿Quiénes somos?, Nuestros servicios, Contáctanos
- Scroll suave a cada sección
- Efecto hover con underline animado
- Navbar fijo al hacer scroll

### Sección ¿Quiénes Somos?
- Card con foto de Daniela Muñoz y datos:
  - Nombre: Daniela Muñoz
  - Rol: Estudiante de Analista Programador
  - Correo: daniela.munoz114@inacapmail.cl

### Sección Nuestros Servicios (DOM)
- **Arreglo de objetos** con mínimo 3 servicios:
  - Nombre
  - Precio por persona
  - Descripción
  - Imagen (URL o ruta local)
- Renderizado dinámico con `mostrarServicios()`
- Tarjetas con hover elevado (box-shadow)

### Mapa de Ubicación
- Google Maps embebido de Punta Arenas
- iframe responsive

### Formulario Contáctanos
- Campos: Nombre, Celular, Email, País, Ciudad, Consulta (textarea)
- Botón "Enviar"
- Validaciones obligatorias:
  - Campos requeridos
  - Email válido (regex)
  - Celular solo numérico
  - Consulta no vacía
- Mensaje de éxito al enviar (alert/modal)
- Función `limpiarFormulario()` tras envío

---

## 5. Component Inventory

### Navbar
- **Default**: Fondo verde primary, texto blanco
- **Links hover**: Underline amarillo accent
- **Scroll**: Sombra sutil añadida

### Card Integrante
- **Default**: Fondo blanco, sombra suave, border-radius 8px
- **Hover**: Elevación con sombra más pronunciada

### Card Servicio
- **Default**: Imagen arriba, texto abajo, sombra suave
- **Hover**: Transform translateY(-5px), sombra fuerte
- **Contains**: Imagen, título precio, descripción

### Form Input
- **Default**: Border gris claro, padding 12px
- **Focus**: Border verde, outline none
- **Error**: Border rojo, mensaje debajo en rojo
- **Valid**: Border verde con checkmark

### Botón Enviar
- **Default**: Fondo azul secondary, texto blanco
- **Hover**: Fondo más oscuro
- **Active**: Escala 0.98
- **Disabled**: Fondo gris, cursor not-allowed

---

## 6. Technical Approach

### Stack
- HTML5 semántico
- CSS3 (sin frameworks, CSS vanilla)
- JavaScript ES6 (vanilla)

### Estructura de Archivos
```
turismo-extremo-sur/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
├── img/
│   └── daniela.jpg
└── SPEC.md
```

### JavaScript Functions Required
```javascript
// Arreglo de servicios
let servicios = [...]

// Renderiza servicios en DOM
function mostrarServicios() { ... }

// Valida todos los campos
function validarFormulario() { ... }

// Limpia el formulario
function limpiarFormulario() { ... }
```

### Imágenes de Servicios
Usar Unsplash o picsum para imágenes placeholder de cada lugar.

---

## 7. Datos del Proyecto

### Integrante
| Campo | Valor |
|-------|-------|
| Nombre | Daniela Muñoz |
| Rol | Estudiante Analista Programador |
| Email | daniela.munoz114@inacapmail.cl |
| Foto | daniela.jpg |

### Servicios
| Servicio | Precio | Descripción |
|----------|--------|-------------|
| Monte Tarn | $25.000 | Caminata guiada al Monte Tarn con vista panorámica |
| Parrillar | $20.000 | Excursión a Parrillar, bosque nativo y fauna local |
| Mirador Zapador Austral | $15.000 | Trekking al mirador con vista al Estrecho de Magallanes |
