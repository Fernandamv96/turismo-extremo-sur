# Guía para Subir el Proyecto a GitHub

## Paso 1: Crear una cuenta en GitHub (si no tienes)

1. Ve a [github.com](https://github.com)
2. Haz clic en "Sign up"
3. Sigue las instrucciones para crear tu cuenta

## Paso 2: Crear un nuevo repositorio

1. Inicia sesión en GitHub
2. Haz clic en el botón verde "New" o "+" en la esquina superior derecha
3. Completa la información:
   - **Repository name**: `turismo-extremo-sur`
   - **Description**: `Sitio web de Turismo Extremo Sur - Empresa de viajes a caballo y caminatas en Punta Arenas`
   - **Public** o **Private**: Elige según prefieras
   - Marca ✅ "Add a README file"
   - Marca ✅ "Add .gitignore" (opcional)

4. Haz clic en "Create repository"

## Paso 3: Subir los archivos al repositorio

Hay dos opciones:

### Opción A: Usando Git desde la terminal

```bash
# 1. Navega a la carpeta del proyecto
cd turismo-extremo-sur

# 2. Inicializa Git
git init

# 3. Agrega todos los archivos
git add .

# 4. Crea tu primer commit
git commit -m "feat: Sitio web Turismo Extremo Sur - Evaluación Sumativa"

# 5. Conecta con el repositorio remoto (reemplaza con tu URL)
git remote add origin https://github.com/TU_USUARIO/turismo-extremo-sur.git

# 6. Sube los archivos
git push -u origin main
```

### Opción B: Subir archivos directamente desde GitHub

1. En tu repositorio nuevo, haz clic en "uploading an existing file"
2. Arrastra todos los archivos del proyecto:
   - `index.html`
   - `SPEC.md`
   - `css/` (carpeta completa con `styles.css`)
   - `js/` (carpeta completa con `main.js`)
   - `img/` (carpeta con tu foto)
3. Haz clic en "Commit changes"

## Estructura del Proyecto

```
turismo-extremo-sur/
├── index.html          (Archivo principal)
├── SPEC.md             (Especificaciones)
├── css/
│   └── styles.css      (Estilos)
├── js/
│   └── main.js         (JavaScript con validaciones)
└── img/
    └── daniela.jpg     (Tu foto)
```

## Comandos Git Útiles

```bash
# Ver estado de archivos
git status

# Ver cambios realizados
git diff

# Ver historial de commits
git log

# Agregar cambios específicos
git add archivo.html

# Hacer commit
git commit -m "tu mensaje"

# Subir cambios
git push
```

## Notas Importantes

- **Tu email del proyecto**: `daniela.munoz114@inacapmail.cl` está incluido en el formulario de contacto
- **El formulario** está configurado para validar todos los campos antes de enviar
- **Los servicios** se cargan dinámicamente desde el arreglo de JavaScript
- El sitio está desplegado en: `https://zucuzygphi4a.space.minimax.io`

## Verificar el Repositorio

Después de subir,你应该 ver:
- ✅ Archivo `index.html`
- ✅ Archivo `SPEC.md`
- ✅ Carpeta `css/` con `styles.css`
- ✅ Carpeta `js/` con `main.js`
- ✅ Carpeta `img/` con tu foto

¡Listo! Tu proyecto está ahora en GitHub y puedes compartir el enlace con tu profesora.
