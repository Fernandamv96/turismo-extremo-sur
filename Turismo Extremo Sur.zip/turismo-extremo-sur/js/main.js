/**
 * ===================================
 * TURISMO EXTREMO SUR - JavaScript
 * ===================================
 *
 * Este archivo contiene:
 * - Arreglo de objetos para servicios
 * - mostrarServicios(): Renderiza servicios dinámicamente usando DOM
 * - validarFormulario(): Valida todos los campos del formulario
 * - limpiarFormulario(): Limpia el formulario después del envío
 */

// ===================================
// ARREGLO DE SERVICIOS (Objetos)
// ===================================
let servicios = [
    {
        nombre: "Caminata al Monte Tarn",
        precio: 25000,
        descripcion: "Una experiencia inolvidable trekking al Monte Tarn, con vistas panorámicas del paisaje patagónico. Incluye guía certificado, equipo de seguridad y snack.",
        imagen: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80"
    },
    {
        nombre: "Caminata a Parrillar",
        precio: 20000,
        descripcion: "Recorre el bosque nativo de Parrillar, descubriendo la flora y fauna local. Excursión perfecta para amantes de la naturaleza y fotografía.",
        imagen: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=600&q=80"
    },
    {
        nombre: "Mirador Zapador Austral",
        precio: 15000,
        descripcion: "Trekking al espectacular mirador con vista privilegiada al Estrecho de Magallanes. Actividad recomendada para todos los niveles de experiencia.",
        imagen: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&q=80"
    },
    {
        nombre: "Cabalgata Rio Grande",
        precio: 35000,
        descripcion: "Vive la experiencia de cabalgar por las extensas praderas patagónicas. Caballos domesticados y guía experimentado incluido. No se requiere experiencia previa.",
        imagen: "https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=600&q=80"
    }
];

// ===================================
// FUNCIÓN: mostrarServicios()
// ===================================
/**
 * Renderiza dinámicamente los servicios en el DOM
 * usando el arreglo de objetos 'servicios'
 */
function mostrarServicios() {
    // Obtener el contenedor donde se mostrarán los servicios
    let serviciosGrid = document.getElementById('services-grid');

    // Verificar que el contenedor exista
    if (!serviciosGrid) {
        console.error('Contenedor de servicios no encontrado');
        return;
    }

    // Limpiar cualquier contenido previo
    serviciosGrid.innerHTML = '';

    // Recorrer el arreglo de servicios y crear los elementos HTML
    servicios.forEach(function(servicio) {
        // Crear el elemento article para la tarjeta de servicio
        let card = document.createElement('article');
        card.className = 'service-card';

        // Formatear el precio con formato chileno
        let precioFormateado = formatCurrency(servicio.precio);

        // Construir el HTML de la tarjeta
        card.innerHTML = `
            <div class="service-image">
                <img src="${servicio.imagen}" alt="${servicio.nombre}">
            </div>
            <div class="service-content">
                <h3 class="service-title">${servicio.nombre}</h3>
                <span class="service-price">${precioFormateado} por persona</span>
                <p class="service-description">${servicio.descripcion}</p>
            </div>
        `;

        // Agregar la tarjeta al contenedor
        serviciosGrid.appendChild(card);
    });
}

// ===================================
// FUNCIÓN: formatCurrency()
// ===================================
/**
 * Formatea un número como moneda chilena (CLP)
 * @param {number} amount - Cantidad a formatear
 * @returns {string} - Cantidad formateada
 */
function formatCurrency(amount) {
    return '$' + amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

// ===================================
// FUNCIÓN: validarFormulario()
// ===================================
/**
 * Valida todos los campos del formulario de contacto
 * @returns {boolean} - true si el formulario es válido, false en caso contrario
 */
function validarFormulario() {
    let esValido = true;

    // Obtener valores de los campos
    let nombre = document.getElementById('nombre').value.trim();
    let celular = document.getElementById('celular').value.trim();
    let email = document.getElementById('email').value.trim();
    let pais = document.getElementById('pais').value.trim();
    let ciudad = document.getElementById('ciudad').value.trim();
    let consulta = document.getElementById('consulta').value.trim();

    // Validar Nombre (requerido)
    if (nombre === '') {
        mostrarError('nombre', 'El nombre es requerido');
        esValido = false;
    } else {
        limpiarError('nombre');
    }

    // Validar Celular (requerido y numérico)
    if (celular === '') {
        mostrarError('celular', 'El celular es requerido');
        esValido = false;
    } else if (!esNumerico(celular)) {
        mostrarError('celular', 'El celular debe contener solo números');
        esValido = false;
    } else {
        limpiarError('celular');
    }

    // Validar Email (requerido y válido)
    if (email === '') {
        mostrarError('email', 'El email es requerido');
        esValido = false;
    } else if (!esEmailValido(email)) {
        mostrarError('email', 'Ingresa un email válido');
        esValido = false;
    } else {
        limpiarError('email');
    }

    // Validar País (requerido)
    if (pais === '') {
        mostrarError('pais', 'El país es requerido');
        esValido = false;
    } else {
        limpiarError('pais');
    }

    // Validar Ciudad (requerido)
    if (ciudad === '') {
        mostrarError('ciudad', 'La ciudad es requerida');
        esValido = false;
    } else {
        limpiarError('ciudad');
    }

    // Validar Consulta (requerido y no vacío)
    if (consulta === '') {
        mostrarError('consulta', 'La consulta no puede estar vacía');
        esValido = false;
    } else if (consulta.length < 10) {
        mostrarError('consulta', 'La consulta debe tener al menos 10 caracteres');
        esValido = false;
    } else {
        limpiarError('consulta');
    }

    return esValido;
}

// ===================================
// FUNCIÓN: mostrarError()
// ===================================
/**
 * Muestra un mensaje de error en un campo específico
 * @param {string} campoId - ID del campo
 * @param {string} mensaje - Mensaje de error a mostrar
 */
function mostrarError(campoId, mensaje) {
    let campo = document.getElementById(campoId);
    let formGroup = campo.closest('.form-group');
    let errorSpan = document.getElementById('error-' + campoId);

    // Agregar clase de error al form-group
    formGroup.classList.add('error');
    formGroup.classList.remove('valid');

    // Mostrar el mensaje de error
    errorSpan.textContent = mensaje;
    errorSpan.style.display = 'block';
}

// ===================================
// FUNCIÓN: limpiarError()
// ===================================
/**
 * Limpia el mensaje de error de un campo específico
 * @param {string} campoId - ID del campo
 */
function limpiarError(campoId) {
    let campo = document.getElementById(campoId);
    let formGroup = campo.closest('.form-group');
    let errorSpan = document.getElementById('error-' + campoId);

    // Remover clase de error y agregar válida
    formGroup.classList.remove('error');
    formGroup.classList.add('valid');

    // Ocultar el mensaje de error
    errorSpan.style.display = 'none';
}

// ===================================
// FUNCIÓN: esNumerico()
// ===================================
/**
 * Verifica si una cadena contiene solo números
 * @param {string} valor - Valor a verificar
 * @returns {boolean} - true si es numérico, false en caso contrario
 */
function esNumerico(valor) {
    // Permitir números, espacios, guión y signo +
    let patron = /^[0-9\s\-\+]+$/;
    return patron.test(valor) && valor.replace(/\D/g, '').length >= 8;
}

// ===================================
// FUNCIÓN: esEmailValido()
// ===================================
/**
 * Verifica si un email tiene formato válido
 * @param {string} email - Email a verificar
 * @returns {boolean} - true si es válido, false en caso contrario
 */
function esEmailValido(email) {
    // Expresión regular para validar email
    let patron = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return patron.test(email);
}

// ===================================
// FUNCIÓN: limpiarFormulario()
// ===================================
/**
 * Limpia todos los campos del formulario después del envío exitoso
 */
function limpiarFormulario() {
    // Obtener referencia al formulario
    let formulario = document.getElementById('contact-form');

    // Resetear el formulario
    formulario.reset();

    // Remover todas las clases de error y válido
    let formGroups = formulario.querySelectorAll('.form-group');
    formGroups.forEach(function(group) {
        group.classList.remove('error', 'valid');
    });

    // Ocultar todos los mensajes de error
    let errorMessages = formulario.querySelectorAll('.error-message');
    errorMessages.forEach(function(msg) {
        msg.style.display = 'none';
    });
}

// ===================================
// FUNCIÓN: mostrarModalExito()
// ===================================
/**
 * Muestra el modal de éxito después del envío del formulario
 */
function mostrarModalExito() {
    let modal = document.getElementById('success-modal');
    if (modal) {
        modal.classList.add('show');
    }
}

// ===================================
// FUNCIÓN: ocultarModalExito()
// ===================================
/**
 * Oculta el modal de éxito
 */
function ocultarModalExito() {
    let modal = document.getElementById('success-modal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// ===================================
// FUNCIÓN: enviarFormulario()
// ===================================
/**
 * Maneja el envío del formulario
 * @param {Event} evento - Evento del formulario
 */
function enviarFormulario(evento) {
    // Prevenir el envío por defecto del formulario
    evento.preventDefault();

    // Validar el formulario
    if (validarFormulario()) {
        // En un entorno real, aquí se enviarían los datos al servidor
        // Por ahora, simulamos el envío mostrando el modal de éxito

        // Mostrar modal de éxito
        mostrarModalExito();

        // Limpiar el formulario
        limpiarFormulario();

        // Log para debugging (en producción se eliminaría)
        console.log('Formulario enviado exitosamente');
    }
}

// ===================================
// FUNCIÓN: scrollNavbar()
// ===================================
/**
 * Agrega sombra a la barra de navegación cuando se hace scroll
 */
function scrollNavbar() {
    let navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
}

// ===================================
// FUNCIÓN: toggleMenu()
// ===================================
/**
 * Toggle del menú móvil
 */
function toggleMenu() {
    let navMenu = document.getElementById('nav-menu');
    let navToggle = document.getElementById('nav-toggle');

    navMenu.classList.toggle('active');
    navToggle.classList.toggle('active');
}

// ===================================
// FUNCIÓN: cerrarMenuAlClick()
// ===================================
/**
 * Cierra el menú móvil cuando se hace click en un enlace
 */
function cerrarMenuAlClick() {
    let navMenu = document.getElementById('nav-menu');
    let navToggle = document.getElementById('nav-toggle');

    navMenu.classList.remove('active');
    navToggle.classList.remove('active');
}

// ===================================
// EVENT LISTENERS
// ===================================

// Cuando el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Renderizar los servicios dinámicamente
    mostrarServicios();

    // Agregar listener al formulario de contacto
    let formulario = document.getElementById('contact-form');
    if (formulario) {
        formulario.addEventListener('submit', enviarFormulario);
    }

    // Agregar listener para el botón de cerrar modal
    let btnCerrarModal = document.querySelector('.btn-close');
    if (btnCerrarModal) {
        btnCerrarModal.addEventListener('click', ocultarModalExito);
    }

    // Agregar listener para cerrar modal al hacer click fuera
    let modal = document.getElementById('success-modal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                ocultarModalExito();
            }
        });
    }

    // Agregar listener para el toggle del menú móvil
    let navToggle = document.getElementById('nav-toggle');
    if (navToggle) {
        navToggle.addEventListener('click', toggleMenu);
    }

    // Agregar listeners a los enlaces del menú para cerrar al hacer click
    let navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function(link) {
        link.addEventListener('click', cerrarMenuAlClick);
    });

    // Agregar listener para el scroll de la página
    window.addEventListener('scroll', scrollNavbar);
});
